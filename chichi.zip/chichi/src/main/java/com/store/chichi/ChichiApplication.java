package com.store.chichi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChichiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChichiApplication.class, args);
	}

}
