package com.store.chichi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChichiApplicationTests {

	@Test
	void contextLoads() {
	}

}
